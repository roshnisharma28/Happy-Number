#include <iostream>
using namespace std;

bool happynum(int num) {
    int sum = 0;
    while (num > 0 || sum > 9) {
        if (num == 0) {
            num = sum;
            sum = 0;
        }
        int digit = num % 10;
        sum += (digit * digit);
        num /= 10;
        cout << "Current digit: " << digit << ", Sum: " << sum << ", Num: " << num << endl;
    }
    return (sum == 1);
}

int main() {
    int num;
    cout << "Enter a number to find out if it is a happy number or not: " << endl;
    cin >> num;
    if (happynum(num)) {
        cout << "It is a happy number!!!" << endl;
    } else {
        cout << "Not a happy number" << endl;
    }
    return 0;
}
